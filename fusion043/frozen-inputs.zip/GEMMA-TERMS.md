# Gemma Terms of Use

The terms below apply to Gemma models listed in the Appendix at bottom of this page. For Gemma 4 terms, see the [Gemma 4 license](apache-2.md).

Last modified: April 1, 2026

By using, reproducing, modifying, distributing, performing or displaying any
portion or element of Gemma, Model Derivatives including via any Hosted Service,
(each as defined below) (collectively, the "**Gemma Services**") or otherwise
accepting the terms of this Agreement, you agree to be bound by this Agreement.

## Section 1: DEFINITIONS

### 1.1 Definitions

(a) "**Agreement** " or "**Gemma Terms of Use**" means these terms and conditions
that govern the use, reproduction, Distribution or modification of the Gemma
Services and any terms and conditions incorporated by reference.

(b) "**Distribution** " or "**Distribute** " means any transmission, publication,
or other sharing of Gemma or Model Derivatives to a third party, including by
providing or making Gemma or its functionality available as a hosted service via
API, web access, or any other electronic or remote means ("**Hosted Service**").

\(c) "**Gemma** " means the set of machine learning language models, trained model
weights and parameters identified in the [Appendix](#appendix),
regardless of the source that you obtained it from.

(d) "**Google**" means Google LLC.

(e) "**Model Derivatives**" means all (i) modifications to Gemma, (ii) works based
on Gemma, or (iii) any other machine learning model which is created by transfer
of patterns of the weights, parameters, operations, or Output of Gemma, to that
model in order to cause that model to perform similarly to Gemma, including
distillation methods that use intermediate data representations or methods based
on the generation of synthetic data Outputs by Gemma for training that model.
For clarity, Outputs are not deemed Model Derivatives.

(f) "**Output**" means the information content output of Gemma or a Model
Derivative that results from operating or otherwise using Gemma or the Model
Derivative, including via a Hosted Service.

### 1.2

As used in this Agreement, "**including** " means
"**including without limitation**".

## Section 2: ELIGIBILITY AND USAGE

### 2.1 Eligibility

You represent and warrant that you have the legal capacity to enter into this
Agreement (including being of sufficient age of consent). If you are accessing
or using any of the Gemma Services for or on behalf of a legal entity, (a) you
are entering into this Agreement on behalf of yourself and that legal entity,
(b) you represent and warrant that you have the authority to act on behalf of
and bind that entity to this Agreement and \(c) references to "**you** " or
"**your**" in the remainder of this Agreement refers to both you (as an
individual) and that entity.

### 2.2 Use

You may use, reproduce, modify, Distribute, perform or display any of the Gemma
Services only in accordance with the terms of this Agreement, and must not
violate (or encourage or permit anyone else to violate) any term of this
Agreement.

## Section 3: DISTRIBUTION AND RESTRICTIONS

### 3.1 Distribution and Redistribution

You may reproduce or Distribute copies of Gemma or Model Derivatives if you meet
all of the following conditions:

1. You must include the use restrictions referenced in Section 3.2 as an enforceable provision in any agreement (e.g., license agreement, terms of use, etc.) governing the use and/or distribution of Gemma or Model Derivatives and you must provide notice to subsequent users you Distribute to that Gemma or Model Derivatives are subject to the use restrictions in Section 3.2.
2. You must provide all third party recipients of Gemma or Model Derivatives a copy of this Agreement.
3. You must cause any modified files to carry prominent notices stating that you modified the files.
4. All Distributions (other than through a Hosted Service) must be accompanied by a "**Notice** " text file that contains the following notice: "**Gemma is provided under and subject to the Gemma Terms of Use found at gemma.ai/resources/terms**".

You may add your own intellectual property statement to your modifications and,
except as set forth in this Section, may provide additional or different terms
and conditions for use, reproduction, or Distribution of your modifications, or
for any such Model Derivatives as a whole, provided your use, reproduction,
modification, Distribution, performance, and display of Gemma otherwise complies
with the terms and conditions of this Agreement. Any additional or different
terms and conditions you impose must not conflict with the terms of this
Agreement.

### 3.2 Use Restrictions

You must not use any of the Gemma Services:

1. for the restricted uses set forth in the Gemma Prohibited Use Policy at [gemma.ai/resources/prohibited_use_policy](prohibited-use.md) ("**Prohibited Use Policy**"), which is hereby incorporated by reference into this Agreement; or
2. in violation of applicable laws and regulations.

To the maximum extent permitted by law, Google reserves the right to restrict
(remotely or otherwise) usage of any of the Gemma Services that Google
reasonably believes are in violation of this Agreement.

### 3.3 Generated Output

Google claims no rights in Outputs you generate using Gemma. You and your users
are solely responsible for Outputs and their subsequent uses.

## Section 4: ADDITIONAL PROVISIONS

### 4.1 Updates

Google may update Gemma from time to time.

### 4.2 Trademarks

Nothing in this Agreement grants you any rights to use Google's trademarks,
trade names, logos or to otherwise suggest endorsement or misrepresent the
relationship between you and Google. Google reserves any rights not expressly
granted herein.

### 4.3 DISCLAIMER OF WARRANTY

UNLESS REQUIRED BY APPLICABLE LAW, THE GEMMA SERVICES, AND OUTPUTS, ARE PROVIDED
ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
EXPRESS OR IMPLIED, INCLUDING ANY WARRANTIES OR CONDITIONS OF TITLE,
NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. YOU ARE
SOLELY RESPONSIBLE FOR DETERMINING THE APPROPRIATENESS OF USING, REPRODUCING,
MODIFYING, PERFORMING, DISPLAYING OR DISTRIBUTING ANY OF THE GEMMA SERVICES
OR OUTPUTS AND ASSUME ANY AND ALL RISKS ASSOCIATED WITH YOUR USE OR DISTRIBUTION
OF ANY OF THE GEMMA SERVICES OR OUTPUTS AND YOUR EXERCISE OF RIGHTS AND
PERMISSIONS UNDER THIS AGREEMENT.

### 4.4 LIMITATION OF LIABILITY

TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT AND UNDER NO
LEGAL THEORY, WHETHER IN TORT (INCLUDING NEGLIGENCE), PRODUCT LIABILITY,
CONTRACT, OR OTHERWISE, UNLESS REQUIRED BY APPLICABLE LAW, SHALL GOOGLE OR ITS
AFFILIATES BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY DIRECT, INDIRECT,
SPECIAL, INCIDENTAL, EXEMPLARY, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR LOST
PROFITS OF ANY KIND ARISING FROM THIS AGREEMENT OR RELATED TO, ANY OF THE GEMMA
SERVICES OR OUTPUTS EVEN IF GOOGLE OR ITS AFFILIATES HAVE BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

### 4.5 Term, Termination, and Survival

The term of this Agreement will commence upon your acceptance of this Agreement
(including acceptance by your use, modification, or Distribution, reproduction,
performance or display of any portion or element of the Gemma Services) and will
continue in full force and effect until terminated in accordance with the terms
of this Agreement. Google may terminate this Agreement if you are in breach of
any term of this Agreement. Upon termination of this Agreement, you must delete
and cease use and Distribution of all copies of Gemma and Model Derivatives in
your possession or control. Sections 1, 2.1, 3.3, 4.2 to 4.9 shall survive the
termination of this Agreement.

### 4.6 Governing Law and Jurisdiction

This Agreement will be governed by the laws of the State of California without
regard to choice of law principles. The UN Convention on Contracts for the
International Sale of Goods does not apply to this Agreement. The state and
federal courts of Santa Clara County, California shall have exclusive
jurisdiction of any dispute arising out of this Agreement.

### 4.7 Severability

If any provision of this Agreement is held to be invalid, illegal or
unenforceable, the remaining provisions shall be unaffected thereby and remain
valid as if such provision had not been set forth herein.

### 4.8 Entire Agreement

This Agreement states all the terms agreed between the parties and supersedes
all other agreements between the parties as of the date of acceptance relating
to its subject matter.

### 4.9 No Waiver

Google will not be treated as having waived any rights by not exercising (or
delaying the exercise of) any rights under this Agreement.

## Appendix

- [Gemma 1](../models/gemma-1/index.md)
- [Gemma 1.1](../models/gemma-1/index.md)
- [Gemma 2](../models/gemma-2/index.md)
- [Gemma 3](../models/gemma-3/index.md)
- [Gemma 3n](../models/gemma-3n/index.md)
- [FunctionGemma](../models/functiongemma/index.md)
- [EmbeddingGemma](../models/embeddinggemma/index.md)
- [PaliGemma](../models/paligemma/model-card-v1.md)
- [PaliGemma 2](../models/paligemma/model-card-v2.md)
- [ShieldGemma](../models/shieldgemma/model-card-v1.md)
- [ShieldGemma 2](../models/shieldgemma/model-card-v2.md)
- [CodeGemma](https://www.kaggle.com/models/google/codegemma)
- [CodeGemma 1.1](https://www.kaggle.com/models/google/codegemma)
- [Gemma 2 JPN](https://huggingface.co/google/gemma-2-2b-jpn-it)
- [DataGemma RIG](https://www.kaggle.com/models/google/datagemma-rig)
- [DataGemma RAG](https://www.kaggle.com/models/google/datagemma-rag)
- [RecurrentGemma](../models/recurrentgemma/model-card.md)
- [Gemma Scope](../models/gemma-scope/index.md)
- [Gemma-APS](../models/gemma-aps/index.md)
- [T5Gemma](https://www.kaggle.com/models/google/t5gemma)
- [VaultGemma](https://www.kaggle.com/models/google/vaultgemma)
- [FunctionGemma](https://www.kaggle.com/models/google/functiongemma)
- [T5Gemma 2](https://www.kaggle.com/models/google/t5gemma-2)
- [TranslateGemma](https://www.kaggle.com/models/google/translategemma)

!!! Note
    Previous versions of these Terms are [archived here](terms-archive/index.md).
